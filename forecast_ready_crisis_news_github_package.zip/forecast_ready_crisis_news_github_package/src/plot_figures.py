    """Reproduce the three proceeding figures without titles or figure footnotes."""
    from pathlib import Path
    import numpy as np
    import pandas as pd
    import matplotlib.pyplot as plt
    from matplotlib.colors import LinearSegmentedColormap
    from helpers import load_clean_data, full_month_subset

    ROOT = Path(__file__).resolve().parents[1]
    RAW = ROOT / "data" / "raw" / "DisasterAccidentCrisis.xlsx"
    FIG_OUT = ROOT / "outputs" / "figures"
    FIG_OUT.mkdir(parents=True, exist_ok=True)

    BLUE_CMAP = LinearSegmentedColormap.from_list(
        "conference_blue", ["#F8FAFC", "#DBEAFE", "#93C5FD", "#3B82F6", "#1D4ED8", "#172554"]
    )

    def setup_style():
        plt.rcParams.update({
            "figure.dpi": 150, "savefig.dpi": 600, "font.family": "DejaVu Sans",
            "font.size": 8.5, "axes.labelsize": 9.5, "xtick.labelsize": 7.5, "ytick.labelsize": 8.0,
            "axes.edgecolor": "#475569", "axes.labelcolor": "#334155", "xtick.color": "#334155", "ytick.color": "#334155",
            "figure.facecolor": "white", "axes.facecolor": "white", "grid.color": "#CBD5E1", "grid.alpha": 0.45
        })

    def build_base():
        df = full_month_subset(load_clean_data(RAW))
        months = pd.period_range("2023-09", "2026-05", freq="M").to_timestamp()
        domain_days = df[["month", "domain", "date"]].drop_duplicates().groupby("month").size().rename("active_domain_days")
        return df, months, domain_days

    def figure_1():
        df, months, domain_days = build_base()
        top_events = df["event"].value_counts().head(10).index.tolist()
        event_month_counts = df[df["event"].isin(top_events)].groupby(["event", "month"]).size().unstack(fill_value=0).reindex(index=top_events, columns=months, fill_value=0)
        data = event_month_counts.astype(float)
        for m in months:
            data[m] = np.where(domain_days.loc[m] > 0, event_month_counts[m] / domain_days.loc[m] * 100, np.nan)
        arr = data.values
        nonzero = arr[np.isfinite(arr) & (arr > 0)]
        p90 = np.percentile(nonzero, 90)
        fig, ax = plt.subplots(figsize=(7.2, 3.85))
        im = ax.imshow(arr, aspect="auto", cmap=BLUE_CMAP, interpolation="nearest", vmin=0)
        for x in np.arange(-0.5, len(months), 1): ax.axvline(x, color="white", linewidth=0.25, alpha=0.65)
        for y in np.arange(-0.5, len(top_events), 1): ax.axhline(y, color="white", linewidth=0.25, alpha=0.65)
        for i in range(arr.shape[0]):
            for j in range(arr.shape[1]):
                if np.isfinite(arr[i, j]) and arr[i, j] >= p90 and arr[i, j] > 0:
                    ax.scatter(j, i, s=13, facecolor="white", edgecolor="#1E3A8A", linewidth=0.45, zorder=3)
        ax.set_xlabel("Month"); ax.set_ylabel("Event category")
        tick_idx = list(range(0, len(months), 2))
        ax.set_xticks(tick_idx); ax.set_xticklabels([months[i].strftime("%Y-%m") for i in tick_idx], rotation=90)
        ax.set_yticks(np.arange(len(top_events))); ax.set_yticklabels(top_events)
        ax.spines["top"].set_visible(False); ax.spines["right"].set_visible(False)
        cbar = fig.colorbar(im, ax=ax, fraction=0.026, pad=0.018)
        cbar.set_label("Records per 100 active source-domain days", rotation=90, labelpad=8)
        fig.tight_layout()
        for ext in ["png", "pdf", "svg"]: fig.savefig(FIG_OUT / f"figure_1_forecast_ready_temporal_signal_map.{ext}", bbox_inches="tight")
        plt.close(fig)

    def figure_2():
        df, months, domain_days = build_base()
        monthly = pd.DataFrame({"month": months})
        monthly = monthly.merge(df.groupby("month").size().rename("raw_records").reset_index(), on="month", how="left")
        monthly = monthly.merge(domain_days.reset_index(), on="month", how="left")
        monthly[["raw_records", "active_domain_days"]] = monthly[["raw_records", "active_domain_days"]].fillna(0)
        monthly["adjusted_rate"] = np.where(monthly["active_domain_days"] > 0, monthly["raw_records"] / monthly["active_domain_days"] * 100, np.nan)
        baseline = (monthly["month"] >= pd.Timestamp("2024-01-01")) & (monthly["month"] <= pd.Timestamp("2025-06-01"))
        monthly["raw_index"] = monthly["raw_records"] / monthly.loc[baseline, "raw_records"].mean() * 100
        monthly["adjusted_index"] = monthly["adjusted_rate"] / monthly.loc[baseline, "adjusted_rate"].mean() * 100
        monthly["exposure_index"] = monthly["active_domain_days"] / monthly.loc[baseline, "active_domain_days"].mean() * 100
        monthly["distortion"] = (monthly["raw_index"] - monthly["adjusted_index"]).abs()
        fig, ax = plt.subplots(figsize=(7.2, 3.9))
        ax.axvspan(pd.Timestamp("2026-01-01"), pd.Timestamp("2026-05-31"), color="#DBEAFE", alpha=0.40, zorder=0)
        ax.plot(monthly["month"], monthly["raw_index"], linewidth=1.8, marker="o", markersize=3.8, label="Raw records index", color="#94A3B8")
        ax.plot(monthly["month"], monthly["adjusted_index"], linewidth=2.1, marker="o", markersize=3.8, label="Exposure-adjusted index", color="#2563EB")
        ax.plot(monthly["month"], monthly["exposure_index"], linewidth=1.8, linestyle="--", marker="o", markersize=3.5, label="Exposure index", color="#60A5FA")
        top_distort = monthly.nlargest(3, "distortion")
        ax.scatter(top_distort["month"], top_distort["raw_index"], s=28, facecolor="white", edgecolor="#1D4ED8", linewidth=0.9, zorder=4)
        ax.set_xlabel("Month"); ax.set_ylabel("Baseline-indexed value (Jan 2024 to Jun 2025 = 100)")
        ax.grid(True, linestyle="--", linewidth=0.45)
        tick_idx = list(range(0, len(monthly), 2))
        ax.set_xticks(monthly["month"].iloc[tick_idx]); ax.set_xticklabels([d.strftime("%Y-%m") for d in monthly["month"].iloc[tick_idx]], rotation=45, ha="right")
        ax.spines["top"].set_visible(False); ax.spines["right"].set_visible(False)
        ax.legend(loc="upper left", frameon=True, fontsize=8.0)
        fig.tight_layout()
        for ext in ["png", "pdf", "svg"]: fig.savefig(FIG_OUT / f"figure_2_signal_distortion_indexed_comparison.{ext}", bbox_inches="tight")
        plt.close(fig)

    def figure_3():
        df, months, domain_days = build_base()
        event_month_counts = df.groupby(["event", "month"]).size().unstack(fill_value=0).reindex(columns=months, fill_value=0)
        event_rates = event_month_counts.copy().astype(float)
        for m in months:
            event_rates[m] = np.where(domain_days.loc[m] > 0, event_month_counts[m] / domain_days.loc[m] * 100, np.nan)
        event_summary = df.groupby("event").agg(records=("event", "size"), distinct_domains=("domain", "nunique"), active_months=("month", "nunique")).reset_index()
        event_summary["mean_adjusted_rate"] = event_summary["event"].map(event_rates.mean(axis=1))
        x_med, y_med = event_summary["active_months"].median(), event_summary["distinct_domains"].median()
        fig, ax = plt.subplots(figsize=(8.2, 4.6), constrained_layout=True)
        sizes = 40 + 850 * (event_summary["records"] / event_summary["records"].max())
        sc = ax.scatter(event_summary["active_months"], event_summary["distinct_domains"], s=sizes, c=event_summary["mean_adjusted_rate"], cmap=BLUE_CMAP, edgecolor="#334155", linewidth=0.6, alpha=0.92, zorder=3)
        xmax = max(event_summary["active_months"]) + 1; ymax = max(event_summary["distinct_domains"]) * 1.08
        ax.axvline(x_med, color="#94A3B8", linestyle="--", linewidth=1.0, zorder=2); ax.axhline(y_med, color="#94A3B8", linestyle="--", linewidth=1.0, zorder=2)
        ax.fill_between([0, x_med], 0, y_med, color="#F8FAFC", alpha=0.60, zorder=0); ax.fill_between([x_med, xmax], 0, y_med, color="#EFF6FF", alpha=0.38, zorder=0)
        ax.fill_between([0, x_med], y_med, ymax, color="#EFF6FF", alpha=0.38, zorder=0); ax.fill_between([x_med, xmax], y_med, ymax, color="#DBEAFE", alpha=0.28, zorder=0)
        key_events = ["Natural Disasters", "Local Crisis and Emergency", "Local Accidents", "Local Infrastructure Event", "Plane Related Accident", "Hurricane Event"]
        offsets = {"Natural Disasters": (12, 10), "Local Crisis and Emergency": (12, 14), "Local Accidents": (12, -14), "Local Infrastructure Event": (12, 12), "Plane Related Accident": (12, 8), "Hurricane Event": (12, -12)}
        for _, row in event_summary[event_summary["event"].isin(key_events)].iterrows():
            dx, dy = offsets.get(row["event"], (10, 8))
            ax.annotate(row["event"], (row["active_months"], row["distinct_domains"]), xytext=(dx, dy), textcoords="offset points", fontsize=7.6, color="#334155", bbox=dict(boxstyle="round,pad=0.20", fc="white", ec="#CBD5E1", lw=0.5, alpha=0.95), arrowprops=dict(arrowstyle="-", color="#94A3B8", lw=0.6, shrinkA=2, shrinkB=4), zorder=4)
        ax.text(x_med * 0.48, y_med * 0.50, "Low readiness", ha="center", va="center", fontsize=8.0, color="#94A3B8")
        ax.text((x_med + xmax) / 2, y_med * 0.48, "Persistent but
source dependent", ha="center", va="center", fontsize=7.8, color="#94A3B8")
        ax.text(x_med * 0.48, (y_med + ymax) / 2, "Broad but
intermittent", ha="center", va="center", fontsize=7.8, color="#94A3B8")
        ax.text((x_med + xmax) / 2, (y_med + ymax) / 2, "High readiness", ha="center", va="center", fontsize=8.2, color="#1E3A8A")
        ax.set_xlabel("Active months"); ax.set_ylabel("Distinct source domains"); ax.grid(True, linestyle="--", linewidth=0.45)
        ax.spines["top"].set_visible(False); ax.spines["right"].set_visible(False)
        cbar = fig.colorbar(sc, ax=ax, orientation="horizontal", fraction=0.08, pad=0.12, aspect=30); cbar.set_label("Mean exposure-adjusted rate")
        handles = [ax.scatter([], [], s=40 + 850*s, color="#93C5FD", edgecolor="#334155", linewidth=0.6) for s in [0.10, 0.35, 0.70]]
        ax.legend(handles, ["Low", "Moderate", "High"], title="Bubble size", loc="upper left", frameon=True, fontsize=7.4, title_fontsize=7.8)
        for ext in ["png", "pdf", "svg"]: fig.savefig(FIG_OUT / f"figure_3_event_forecast_readiness_map.{ext}", bbox_inches="tight")
        plt.close(fig)

    def main():
        setup_style()
        figure_1(); figure_2(); figure_3()
        print("Figures written to outputs/figures.")

    if __name__ == "__main__":
        main()
