"""Compute exposure-normalized crisis news signal tables."""
from pathlib import Path
import numpy as np
import pandas as pd
from helpers import load_clean_data, full_month_subset

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw" / "DisasterAccidentCrisis.xlsx"
DATA_OUT = ROOT / "data" / "processed"
TABLE_OUT = ROOT / "outputs" / "tables"
DATA_OUT.mkdir(parents=True, exist_ok=True)
TABLE_OUT.mkdir(parents=True, exist_ok=True)

def main():
    df = load_clean_data(RAW)
    full = full_month_subset(df)
    months = pd.period_range("2023-09", "2026-05", freq="M").to_timestamp()

    monthly_records = full.groupby("month").size().rename("raw_records")
    monthly_domains = full.groupby("month")["domain"].nunique().rename("active_domains")
    monthly_domain_days = full[["month", "domain", "date"]].drop_duplicates().groupby("month").size().rename("active_domain_days")
    monthly = pd.DataFrame({"month": months})
    for table in [monthly_records, monthly_domains, monthly_domain_days]:
        monthly = monthly.merge(table.reset_index(), on="month", how="left")
    monthly[["raw_records", "active_domains", "active_domain_days"]] = monthly[["raw_records", "active_domains", "active_domain_days"]].fillna(0)
    monthly["rate_per_100_domain_days"] = np.where(
        monthly["active_domain_days"] > 0,
        monthly["raw_records"] / monthly["active_domain_days"] * 100,
        np.nan
    )
    baseline = (monthly["month"] >= pd.Timestamp("2024-01-01")) & (monthly["month"] <= pd.Timestamp("2025-06-01"))
    monthly["baseline_raw_index"] = monthly["raw_records"] / monthly.loc[baseline, "raw_records"].mean() * 100
    monthly["baseline_adjusted_index"] = monthly["rate_per_100_domain_days"] / monthly.loc[baseline, "rate_per_100_domain_days"].mean() * 100
    monthly["baseline_exposure_index"] = monthly["active_domain_days"] / monthly.loc[baseline, "active_domain_days"].mean() * 100
    monthly["signal_distortion_index"] = (monthly["baseline_raw_index"] - monthly["baseline_adjusted_index"]).abs()
    monthly_export = monthly.copy()
    monthly_export["month"] = monthly_export["month"].dt.strftime("%Y-%m")
    monthly_export.to_csv(DATA_OUT / "monthly_exposure_signal.csv", index=False)
    monthly_export.to_csv(TABLE_OUT / "table_raw_vs_adjusted_signal.csv", index=False)

    event_month_counts = full.groupby(["event", "month"]).size().unstack(fill_value=0).reindex(columns=months, fill_value=0)
    active_days = monthly.set_index("month")["active_domain_days"]
    event_rates = event_month_counts.copy().astype(float)
    for m in months:
        event_rates[m] = np.where(active_days.loc[m] > 0, event_month_counts[m] / active_days.loc[m] * 100, np.nan)
    rates_export = event_rates.copy()
    rates_export.columns = [c.strftime("%Y-%m") for c in rates_export.columns]
    rates_export.reset_index().to_csv(DATA_OUT / "event_monthly_exposure_adjusted_rates.csv", index=False)

    source_event = full.groupby(["domain", "event"]).size().rename("records").reset_index()
    event_summary = full.groupby("event").agg(
        records=("event", "size"),
        distinct_domains=("domain", "nunique"),
        active_months=("month", "nunique")
    ).reset_index()
    event_summary["share_percent"] = event_summary["records"] / event_summary["records"].sum() * 100
    event_summary["mean_adjusted_rate"] = event_summary["event"].map(event_rates.mean(axis=1))
    event_summary["readiness_score"] = (
        0.35 * (event_summary["active_months"] / event_summary["active_months"].max()) +
        0.35 * (event_summary["distinct_domains"] / event_summary["distinct_domains"].max()) +
        0.30 * (event_summary["records"] / event_summary["records"].max())
    )
    x_med, y_med = event_summary["active_months"].median(), event_summary["distinct_domains"].median()
    event_summary["readiness_class"] = event_summary.apply(
        lambda r: "High readiness" if r.active_months >= x_med and r.distinct_domains >= y_med else
                  "Persistent but source dependent" if r.active_months >= x_med else
                  "Broad but intermittent" if r.distinct_domains >= y_med else "Low readiness",
        axis=1
    )
    event_summary = event_summary.sort_values(["readiness_score", "records"], ascending=[False, False])
    event_summary.to_csv(DATA_OUT / "event_readiness_metrics.csv", index=False)
    event_summary.head(12).to_csv(TABLE_OUT / "table_event_readiness_indicators.csv", index=False)

    dataset_summary = pd.DataFrame([
        ["Valid records in corpus", len(df), "Input scope after valid event, timestamp, URL, and source-domain parsing"],
        ["Full-month records used for figures", len(full), "Temporal analysis from 2023-09 to 2026-05"],
        ["Event categories", df["event"].nunique(), "Multiclass event taxonomy"],
        ["Distinct source domains", df["domain"].nunique(), "Acquisition source surface"],
        ["Observed source-event edges", len(source_event), "Weighted bipartite links where a source reports an event category"],
        ["Main normalized signal", "Records per 100 active source-domain days", "Forecast-ready reporting intensity measure"],
        ["Rating column", "Excluded", "Avoids unvalidated severity or salience interpretation"]
    ], columns=["Metric", "Value", "Analytical role"])
    dataset_summary.to_csv(TABLE_OUT / "table_dataset_and_signal_construction.csv", index=False)
    print("Signal tables written.")

if __name__ == "__main__":
    main()
