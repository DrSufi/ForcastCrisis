"""Prepare cleaned crisis news metadata and aggregate signal inputs."""
from pathlib import Path
import numpy as np
import pandas as pd
from helpers import load_clean_data, full_month_subset

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw" / "DisasterAccidentCrisis.xlsx"
OUT = ROOT / "data" / "processed"
OUT.mkdir(parents=True, exist_ok=True)

def main():
    df = load_clean_data(RAW)
    full = full_month_subset(df)
    export = full[["title", "event", "datetime", "url", "domain", "date", "month"]].copy()
    export["datetime"] = export["datetime"].dt.strftime("%Y-%m-%d %H:%M:%S")
    export["date"] = pd.to_datetime(export["date"]).dt.strftime("%Y-%m-%d")
    export["month"] = pd.to_datetime(export["month"]).dt.strftime("%Y-%m")
    export.to_csv(OUT / "clean_crisis_news_metadata.csv", index=False)
    print(f"Prepared {len(export):,} full-month records.")

if __name__ == "__main__":
    main()
