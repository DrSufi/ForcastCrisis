"""Helper functions for forecast-ready crisis news signal analysis."""
from urllib.parse import urlparse
import numpy as np
import pandas as pd

def extract_domain(url):
    """Return a canonical source domain from a URL string."""
    try:
        netloc = urlparse(str(url)).netloc.lower().strip()
        if netloc.startswith("www."):
            netloc = netloc[4:]
        return netloc if netloc else np.nan
    except Exception:
        return np.nan

def load_clean_data(path):
    """Load the raw spreadsheet, exclude Rating, parse datetimes, and derive source domains."""
    df = pd.read_excel(path)
    df = df.rename(columns={
        "Title": "title",
        "Event Code": "event",
        "Event DateTime": "datetime",
        "Source URL": "url"
    })
    for col in list(df.columns):
        if col.lower().strip() == "rating":
            df = df.drop(columns=[col])
    df = df[["title", "event", "datetime", "url"]].copy()
    df = df.dropna(subset=["event", "datetime", "url"])
    df["event"] = df["event"].astype(str).str.strip()
    df["datetime"] = pd.to_datetime(df["datetime"], errors="coerce")
    df = df.dropna(subset=["datetime"])
    df["domain"] = df["url"].apply(extract_domain)
    df = df.dropna(subset=["domain"])
    df["date"] = df["datetime"].dt.floor("D")
    df["month"] = df["datetime"].dt.to_period("M").dt.to_timestamp()
    return df

def full_month_subset(df):
    """Restrict to complete monthly inference window used in the proceeding paper."""
    return df[(df["month"] >= pd.Timestamp("2023-09-01")) & (df["month"] <= pd.Timestamp("2026-05-01"))].copy()
