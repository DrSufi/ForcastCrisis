"""Run the full data, table, and figure workflow."""
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ["prepare_data.py", "analyze_signals.py", "plot_figures.py"]

for script in SCRIPTS:
    print(f"Running {script}...")
    subprocess.run([sys.executable, str(ROOT / "src" / script)], check=True)
print("Workflow complete.")
