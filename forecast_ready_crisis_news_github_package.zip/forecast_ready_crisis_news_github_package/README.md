# Forecast Ready Crisis News Signals

This repository contains the data products and Python code used to construct forecast ready crisis news indicators for the conference proceeding paper:

**From Raw Crisis Counts to Forecast Ready Signals: Exposure Normalized and Network Aware Indicators from Global News Streams**

The workflow converts a heterogeneous crisis news stream into exposure normalized and source aware signal products. The analysis excludes the `Rating` column and uses only event title, event category, timestamp, source URL, derived source domain, and monthly acquisition exposure.

## Repository structure

```text
data/raw/DisasterAccidentCrisis.xlsx              Original input spreadsheet
data/processed/clean_crisis_news_metadata.csv     Cleaned record-level metadata
data/processed/monthly_exposure_signal.csv        Monthly raw, exposure, and indexed signals
data/processed/event_monthly_exposure_adjusted_rates.csv
data/processed/event_readiness_metrics.csv
outputs/tables/                                  CSV tables used in the paper
outputs/figures/                                 PNG, PDF, and SVG versions of Figures 1 to 3
src/                                             Reproducible Python scripts
```

## Analytical scope

The processed full-month analysis contains:

- **71,894** full-month records from September 2023 to May 2026
- **20** event categories
- **772** distinct source domains
- **2,540** observed source-event edges
- Exposure normalized intensity measured as **records per 100 active source-domain days**

## Reproduce the analysis

Create a Python environment and install the dependencies:

```bash
pip install -r requirements.txt
```

Run the complete workflow:

```bash
python src/build_all.py
```

Or run each stage separately:

```bash
python src/prepare_data.py
python src/analyze_signals.py
python src/plot_figures.py
```

## Main outputs

- Figure 1: Forecast ready temporal signal map
- Figure 2: Raw versus exposure adjusted signal distortion comparison
- Figure 3: Event forecast readiness map
- Table 1: Dataset and signal construction summary
- Table 2: Event forecast readiness indicators
- Table 3: Raw versus exposure corrected signal comparison

## Data use note

The dataset contains news titles and source URLs used for scholarly reproducibility. Before publishing this repository publicly, confirm that redistribution is consistent with the terms of the original data sources and institutional requirements. Aggregated CSV outputs are included to support transparent verification without requiring users to inspect individual records.

## Citation

Please cite the associated conference proceeding if using this package. A `CITATION.cff` file is included for convenience.
