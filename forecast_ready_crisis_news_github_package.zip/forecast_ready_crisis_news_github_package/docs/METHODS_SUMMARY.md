# Methods Summary

Let `N_t` denote the number of records acquired in month `t`. Let `V_t` be the set of active source domains in month `t`, and let `Q_{vt}` be the set of days in month `t` on which source `v` contributed at least one retained record.

Monthly acquisition exposure is

`E_t = sum_{v in V_t} |Q_{vt}|`.

The exposure normalized signal is

`R_t = 100 * N_t / E_t`.

Indexed raw and adjusted signals are computed relative to the baseline period from January 2024 to June 2025. The signal distortion index is the absolute difference between the baseline-indexed raw signal and the baseline-indexed exposure adjusted signal.
