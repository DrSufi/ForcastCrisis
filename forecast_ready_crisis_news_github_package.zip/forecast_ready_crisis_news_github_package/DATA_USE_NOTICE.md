# Data Use Notice

This package includes crisis news metadata for scholarly reproducibility. The analytical workflow uses titles, event labels, timestamps, source URLs, and derived source domains. The `Rating` field is intentionally excluded from all analyses.

Before making the repository public, confirm that the record-level metadata can be redistributed under the terms of the original sources, journal or conference requirements, and institutional policies. If redistribution of record-level metadata is not permitted, keep `data/raw/` and `data/processed/clean_crisis_news_metadata.csv` private and publish only the aggregate products under `data/processed/` and `outputs/tables/`.
